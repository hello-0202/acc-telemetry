# speed-hud

一个圆形迈速表悬浮窗：`modes: ["overlay"]`，`fit: "contain"`，设计尺寸 **240×240**，背景全透明。

## 装到软件里

设置页 → 主题 → **导入主题包** → 选这个 zip。
导入后目录是 `<LOCALAPPDATA>/acc-telemetry/themes/speed-hud/`，卡片名就是 `speed-hud`。

## 屏幕上都有什么

| 位置 | 含义 | 字段 |
|---|---|---|
| 270° 外弧 | 速度进度，0..320 km/h 铺满；<60% 绿 / <85% 橙 / 更高红 | `car.speed` |
| 内侧刻度 | 16 格，每格 40 km/h | 静态 |
| 环心大字 | 当前速度 km/h | `car.speed` |
| 环心小字 | 单位 | 静态 |
| 底部方牌 | 档位，`-1` 显示 R、`0` 显示 N | `car.gear` / `car.gearText` |

字段为空时速度显示 `--`、弧归零，不会把上一帧的值留在屏上。

## 想改的话

| 想改 | 改哪里 |
|---|---|
| 表盘量程 | `theme.js` 的 `var MAX_KMH = 320` |
| 弧的粗细 | `theme.css` 的 `.sp-track` / `.sp-fill` 的 `stroke-width`（两处要一起改） |
| 分档阈值和颜色 | `theme.js` 的 `setArc()` 里 `p < 0.6 / p < 0.85`；颜色在 `.sp-fill.s-low / .s-mid / .s-high` |
| 数字大小 | `.read b { font-size: 64px }` |
| 刻度格数 | `.tick` / `.tick-bed` 的 `stroke-dasharray`：16 格 = `1 3.6875`（单位是 pathLength=75 的归一化长度） |
| 整体尺寸 | `theme.json` 的 `design`；改完悬浮窗会按新尺寸重开，内部 px 要一起调 |

## 两条硬约束

1. **60ms 一刷新，任何属性都不要加 CSS 过渡**。过渡会被下一帧反复打断，弧长和颜色会卡在上一帧。
2. `theme.json` 的 `id` 必须等于文件夹名，`modes` 只能是 `overlay` / `monitor`，`fit` 只能是 `contain` / `fluid` —— 写错设置页会标红、悬浮窗不加载。
