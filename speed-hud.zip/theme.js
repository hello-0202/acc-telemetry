/* speed-hud —— 主题侧脚本（fit: contain）。
 *
 * 与宿主的约定（postMessage）：
 *   主题 → 宿主：{ type: 'acc:ready' }                    我好了，可以喂数据（每次 init 都要回）
 *   宿主 → 主题：{ type: 'acc:init', v, mode, design, fit, background, theme }
 *   宿主 → 主题：{ type: 'acc:ui', theme?, background? }  切黑白 / 透明背景时补发
 *   宿主 → 主题：{ type: 'acc:state', payload }           录制中 30Hz / 待机 2Hz
 *
 * 独立打开（双击 index.html）没有宿主，直接跑演示波形，方便调样式。
 */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  // isFinite(null) === true 是个坑：真机 null 字段必须先挡掉
  function num(v) { return typeof v === 'number' && isFinite(v) ? v : null; }
  function clamp01(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }

  var MAX_KMH = 320; // 表盘量程：0..320 km/h 铺满 270°

  var hud = $('hud');
  var speedEl = $('speed');
  var gearEl = $('gear');
  var arc = $('sp-fill');

  var lastSpeed = null;
  var lastGear = null;

  var gotState = false;
  var demoTimer = null;
  var demoTick = null;

  function sayReady() {
    // 幂等：宿主每次 init 都回一次 ready（第一条 ready 常早于宿主监听，会丢）
    try { window.parent.postMessage({ type: 'acc:ready' }, '*'); } catch (e) { /* ignore */ }
  }

  function applyUi(msg) {
    if (msg.theme) document.documentElement.dataset.theme = msg.theme;
    if (msg.background === 'transparent' || msg.background === 'opaque') {
      document.documentElement.dataset.bg = msg.background;
    }
  }

  /* 速度弧：pathLength=100，270° = 75 单位 */
  function setArc(p) {
    arc.style.strokeDasharray = (75 * p).toFixed(2) + ' 100';
    arc.style.opacity = p > 0.002 ? '1' : '0';
    // 只有档位变化才改 class：每帧 setAttribute 会让样式反复失效重算
    var cls = 'sp-fill ' + (p < 0.6 ? 's-low' : p < 0.85 ? 's-mid' : 's-high');
    if (arc.getAttribute('class') !== cls) arc.setAttribute('class', cls);
  }

  function gearText(gear, gearTextGiven) {
    if (typeof gearTextGiven === 'string' && gearTextGiven) return gearTextGiven;
    if (gear === -1) return 'R';
    if (gear == null || gear === 0) return 'N';
    return String(gear);
  }

  function setGear(gear, gearTextGiven) {
    var txt = gearText(gear, gearTextGiven);
    if (txt === lastGear) return;
    lastGear = txt;
    gearEl.textContent = txt;
    var way = txt === 'R' ? 'r' : txt === 'N' ? 'n' : '';
    if (way) gearEl.setAttribute('data-way', way);
    else gearEl.removeAttribute('data-way');
  }

  function render(st) {
    try {
      hud.dataset.status = st.status || 'idle';
      var car = st.car || {};

      var sp = num(car.speed);
      if (sp == null) {
        if (lastSpeed !== null) { speedEl.textContent = '--'; lastSpeed = null; }
        setArc(0);
      } else {
        var shown = Math.round(sp < 0 ? 0 : sp);
        if (shown !== lastSpeed) { speedEl.textContent = String(shown); lastSpeed = shown; }
        setArc(clamp01(sp / MAX_KMH));
      }

      setGear(car.gear, car.gearText);
    } catch (e) {
      // 单帧脏数据不能让表停更
      console.warn('[speed-hud] render failed', e);
    }
  }

  window.addEventListener('message', function (ev) {
    var m = ev.data;
    if (!m || typeof m !== 'object') return;
    if (m.type === 'acc:init') { applyUi(m); sayReady(); return; }
    if (m.type === 'acc:ui') { applyUi(m); return; }
    if (m.type === 'acc:state' && m.payload) {
      gotState = true;
      stopDemo();
      render(m.payload);
    }
  });

  var framed = false;
  try { framed = !!(window.parent && window.parent !== window); } catch (e) { framed = false; }

  if (framed) {
    // 有宿主就只等真实 state；后端没起来时保持占位，不跑演示数据
    sayReady();
  } else {
    // 双击 index.html 直接打开：纯本地演示，方便调样式
    startDemo();
  }

  /* ------------------------------ 演示数据 ------------------------------ */
  function startDemo() {
    stopDemo();
    var t = 0;
    demoTick = setInterval(function () {
      if (gotState) { stopDemo(); return; }
      t += 1;
      var speed = 176 + Math.sin(t / 12) * 118; // 58 .. 294
      render({
        status: 'streaming',
        car: {
          speed: speed < 0 ? 0 : speed,
          gear: speed > 250 ? 5 : speed > 200 ? 4 : speed > 140 ? 3 : 2,
        },
      });
    }, 60);
  }

  function stopDemo() {
    if (demoTick !== null) { clearInterval(demoTick); demoTick = null; }
    if (demoTimer !== null) { clearTimeout(demoTimer); demoTimer = null; }
  }
})();
