/* panel-dash —— 主面板主题脚本（fit: fluid）。
 *
 * 与宿主的约定（postMessage）：
 *   主题 → 宿主：{ type: 'acc:ready' }                    我好了，可以喂数据（每次 init 都要回）
 *   宿主 → 主题：{ type: 'acc:init', v, mode, design, fit, box, theme }
 *   宿主 → 主题：{ type: 'acc:ui', theme }                 切黑白主题时补发
 *   宿主 → 主题：{ type: 'acc:state', payload }            录制中 30Hz / 待机 2Hz
 *
 * 独立打开（双击 index.html）没有宿主，直接跑演示波形，方便调样式。
 */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };

  /* 真机字段可能是 null：Number(null) === 0、isFinite(null) 为真，
   * 紧接着 toFixed() 会抛 TypeError，整帧渲染中断。只有真正的数字才放行。 */
  function num(v) { return typeof v === 'number' && isFinite(v) ? v : null; }

  function pad(n, w) {
    var s = String(Math.abs(n));
    while (s.length < w) s = '0' + s;
    return s;
  }

  function fmtLap(ms) {
    if (ms == null || !isFinite(ms) || ms <= 0) return '--:--.---';
    return Math.floor(ms / 60000) + ':' + pad(Math.floor((ms % 60000) / 1000), 2) + '.' + pad(Math.floor(ms % 1000), 3);
  }

  function fmtDelta(ms) {
    if (ms == null || !isFinite(ms)) return '--.---';
    return (ms < 0 ? '-' : '+') + (Math.abs(ms) / 1000).toFixed(3);
  }

  function gearText(gear, given) {
    if (typeof given === 'string' && given) return given;
    if (gear === -1) return 'R';
    if (gear == null || gear === 0) return 'N';
    return String(gear);
  }

  var SESSION = {
    unknown: '未知', practice: '练习', qualify: '排位', race: '正赛', hotlap: '飞驰圈',
    hotstint: '热圈', timeattack: '计时赛', drift: '漂移', drag: '直线加速',
  };

  var STATUS = {
    idle: '待机', streaming: '已连接', waiting: '等待游戏',
    connecting: '连接中', error: '连接断开', stopped: '已停止',
  };

  var wrap = $('wrap');
  var tireEls = Array.prototype.slice.call(document.querySelectorAll('.row.tire'));

  /* ------------------------------ 渲染 ------------------------------ */

  function paintTire(el, w) {
    var p = num(w.pressure);
    var t = num(w.temp);
    var b = num(w.brakeTemp);

    var ep = el.querySelector('[data-k="p"]');
    var et = el.querySelector('[data-k="t"]');
    var eb = el.querySelector('[data-k="b"]');

    ep.textContent = p === null ? '–' : p.toFixed(1);
    et.textContent = t === null ? '–' : Math.round(t) + '°';
    eb.textContent = b === null ? '–' : Math.round(b) + '°';

    et.className = 'v' + (t === null ? '' : t < 60 ? ' n' : t > 105 ? ' h' : '');
    eb.className = 'v' + (b === null ? '' : b > 640 ? ' h' : b > 480 ? ' w' : '');
  }

  function render(st) {
    var car = st.car || {};
    var lap = st.lap || {};
    var track = st.track || {};
    var session = st.session || {};

    wrap.dataset.status = st.status || 'idle';

    var status = $('status');
    status.textContent = STATUS[st.status] || '待机';

    $('track').textContent = track.title || track.name || '—';
    $('session').textContent = SESSION[session.type] || '未知';

    var speed = num(car.speed);
    $('speed').textContent = speed === null ? '--' : String(Math.round(speed));

    $('gear').textContent = gearText(car.gear, car.gearText);

    var maxRpm = num(car.maxRpmCurrent) || num(car.maxRpm) || 7600;
    var rpm = num(car.rpm);
    $('rpmTxt').textContent = (rpm === null ? '—' : String(Math.round(rpm))) + ' rpm';
    $('rpmMax').textContent = '红线 ' + Math.round(maxRpm);
    $('rpmFill').style.width = rpm === null ? '0%' : (Math.min(1, Math.max(0, rpm / maxRpm)) * 100).toFixed(1) + '%';

    var gl = num(car.gLat);
    var gn = num(car.gLong);
    $('gLat').textContent = gl === null ? '—' : (gl < 0 ? '' : '+') + gl.toFixed(2);
    $('gLong').textContent = gn === null ? '—' : (gn < 0 ? '' : '+') + gn.toFixed(2);

    var d = lap.deltaMs;
    var deltaEl = $('delta');
    if (d == null || !isFinite(d)) {
      deltaEl.textContent = '--.---';
      deltaEl.className = 'delta';
    } else {
      deltaEl.textContent = fmtDelta(d);
      deltaEl.className = 'delta ' + (d < 0 ? 'neg' : 'pos');
    }

    $('lapCur').textContent = fmtLap(lap.timeMs);
    $('lapLast').textContent = fmtLap(lap.lastMs);
    $('lapBest').textContent = fmtLap(lap.bestMs);
    $('lapPb').textContent = fmtLap(lap.pbMs);

    var done = num(lap.completed);
    var total = num(session.lapsTotal);
    $('lapDone').textContent = done === null ? '—' : total ? done + ' / ' + total : String(done);

    var wheels = Array.isArray(st.wheels) ? st.wheels : [];
    for (var i = 0; i < tireEls.length; i += 1) paintTire(tireEls[i], wheels[i] || {});

    var thr = num(car.throttle);
    var brk = num(car.brake);
    var steer = num(car.steer);

    var thrP = thr === null ? 0 : Math.min(1, Math.max(0, thr));
    var brkP = brk === null ? 0 : Math.min(1, Math.max(0, brk));
    var steerP = steer === null ? 0 : Math.min(1, Math.max(-1, steer));

    $('thrFill').style.width = (thrP * 100).toFixed(0) + '%';
    $('brkFill').style.width = (brkP * 100).toFixed(0) + '%';
    $('thrVal').textContent = thr === null ? '—' : Math.round(thrP * 100) + '%';
    $('brkVal').textContent = brk === null ? '—' : Math.round(brkP * 100) + '%';

    // 方向盘：从中线向左右生长，满舵 ±450° 占半宽
    var sw = Math.abs(steerP) * 50;
    var strFill = $('strFill');
    strFill.style.width = sw.toFixed(1) + '%';
    strFill.style.left = (steerP >= 0 ? 50 : 50 - sw).toFixed(1) + '%';
    $('strVal').textContent = steer === null ? '—' : Math.round(steerP * 450) + '°';

    var fuel = num(car.fuel);
    var maxFuel = num(car.maxFuel);
    $('fuelFill').style.width = fuel === null || !maxFuel ? '0%' : (Math.min(1, Math.max(0, fuel / maxFuel)) * 100).toFixed(1) + '%';
    $('fuelVal').textContent = fuel === null ? '—' : fuel.toFixed(1) + ' L';
  }

  /* ------------------------------ 协议 ------------------------------ */

  var gotState = false;
  var demoTimer = null;
  var demoTick = null;

  function sayReady() {
    // 幂等：宿主每次 init 都回一次 ready（第一条 ready 常早于宿主监听，会丢）
    try { window.parent.postMessage({ type: 'acc:ready' }, '*'); } catch (e) { /* ignore */ }
  }

  function applyUi(msg) {
    if (msg.theme) document.documentElement.dataset.theme = msg.theme;
  }

  window.addEventListener('message', function (ev) {
    var m = ev.data;
    if (!m || typeof m !== 'object') return;
    if (m.type === 'acc:init') { applyUi(m); sayReady(); return; }
    if (m.type === 'acc:ui') { applyUi(m); return; }
    if (m.type === 'acc:state' && m.payload) {
      gotState = true;
      stopDemo();
      // 单帧脏数据不能让面板停更
      try { render(m.payload); } catch (e) { console.warn('[panel-dash] render failed', e); }
    }
  });

  var framed = false;
  try { framed = !!(window.parent && window.parent !== window); } catch (e) { framed = false; }

  if (framed) {
    // 有宿主（主面板 / 悬浮窗 / 预览窗）就只等真实 state；后端没起来时保持占位，
    // 不跑演示数据 —— 否则没开游戏时面板会一直显示假的流动数据，看起来像真实遥测
    sayReady();
  } else {
    // 双击 index.html 直接打开：纯本地演示，方便调样式
    startDemo();
  }

  /* ------------------------------ 演示数据 ------------------------------ */

  function startDemo() {
    stopDemo();
    var t = 0;
    demoTick = setInterval(function () {
      if (gotState) { stopDemo(); return; }
      t += 1;
      var wave = Math.sin(t / 11);
      var speed = 196 + wave * 82;
      var braking = speed < 150;
      render({
        status: 'streaming',
        session: { type: 'race', lapsTotal: 20 },
        track: { title: 'Monza' },
        car: {
          speed: speed,
          gear: speed > 240 ? 5 : speed > 190 ? 4 : speed > 140 ? 3 : 2,
          rpm: 4300 + wave * 2400,
          maxRpmCurrent: 7600,
          throttle: braking ? 0 : 0.94,
          brake: braking ? 0.42 : 0,
          steer: Math.sin(t / 7) * 0.62,
          fuel: 42.3,
          maxFuel: 100,
          gLat: -1.42 + wave * 0.55,
          gLong: 0.86 - wave * 0.3,
        },
        lap: { timeMs: 41230 + t * 70, lastMs: 92480, bestMs: 91820, pbMs: 91540, deltaMs: wave * 620, completed: 7 },
        wheels: [
          { corner: 'FL', pressure: 27.4, temp: 78, brakeTemp: 412 },
          { corner: 'FR', pressure: 27.6, temp: 81, brakeTemp: 428 },
          { corner: 'RL', pressure: 27.1, temp: 75, brakeTemp: 355 },
          { corner: 'RR', pressure: 27.2, temp: 106, brakeTemp: 662 },
        ],
      });
    }, 70);
  }

  function stopDemo() {
    if (demoTick !== null) { clearInterval(demoTick); demoTick = null; }
    if (demoTimer !== null) { clearTimeout(demoTimer); demoTimer = null; }
  }
})();
