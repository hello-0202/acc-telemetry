# panel-dash

一个四宫格主面板：`modes: ["monitor"]`，`fit: "fluid"`，设计尺寸 1200×640（fluent 模式下只当预览宽高比）。

## 装到软件里

设置页 → 主题 → **导入主题包** → 选这个 zip。
导入后目录是 `<LOCALAPPDATA>/acc-telemetry/themes/panel-dash/`。

## 四张卡

| 卡片 | 内容 | 字段 |
|---|---|---|
| 左上 速度 | 大号速度、转速条、红线值、G 值、档位、DELTA | `car.speed` `car.rpm` `car.maxRpm*` `car.gLat/gLong` `car.gear` `lap.deltaMs` |
| 右上 圈速 | 本圈 / 上一圈 / 本次最佳 / 历史最佳 / 已完成 | `lap.timeMs` `lastMs` `bestMs` `pbMs` `completed`、`session.lapsTotal` |
| 左下 轮胎 | 四轮胎压 psi、胎温 ℃、刹车盘温 ℃ | `wheels[]` |
| 右下 踏板 | 油门 / 刹车 / 方向盘 / 油量 | `car.throttle` `brake` `steer` `fuel` `maxFuel` |

着色规则：胎温 <60℃ 蓝、>105℃ 红；刹车温 >480℃ 黄、>640℃ 红；DELTA 负绿正红。

## 想改的话

| 想改 | 改哪里 |
|---|---|
| 整体字号 | `theme.css` 的 `html { font-size: clamp(10px, calc(1.35vh + 0.32vw), 19px) }`，其余全是 rem，改这一个数字整块等比变 |
| 配色 | `:root` 里的变量；浅色主题在 `html[data-theme="light"]` 覆盖 |
| 列宽比例 | `.grid { grid-template-columns: 1.08fr 1fr }` |
| 加一行数据 | 在 `index.html` 对应卡片里加元素，再到 `theme.js` 的 `render()` 里赋值 |

## 注意

- **fluid 模式不做整体缩放**：iframe 铺满数据区，视口就是容器，所以只能写 `rem` / `%`，
  不要写死 px，也不要写媒体查询断点。
- 字段可能是 `null`（不同车/赛道拿得到的量不同），统一用 `num()` 判空再 `toFixed`，
  否则 `null.toFixed()` 抛异常会让整帧渲染中断。
- 主题不发网络请求、不连 WebSocket，数据只能从 `acc:state` 来。
